package com.cn;

import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

import javax.websocket.Session;

import com.alibaba.fastjson.JSON;
import com.cn.websocket.MyWebSocket;

public class Teat {
	public static Queue<String> boyMatchingQueue = new LinkedList<String>();
	public static Queue<String> girlMatchingQueue = new LinkedList<String>();
	public static void main(String[] args) {
		boyMatchingQueue.offer("11111111111111");
		girlMatchingQueue.offer("2222222222222");
		new Thread(new Runnable(){

			@Override
			public void run() {
				while(true){
					synchronized (boyMatchingQueue) {
						System.out.println("=========11111111111=======");
						String girlSessionId = "";
						System.out.println("boyMatchingQueue:"+boyMatchingQueue.isEmpty());
						System.out.println("girlMatchingQueue:"+!Teat.girlMatchingQueue.isEmpty());
						while(boyMatchingQueue.isEmpty());
						String boySessionId = boyMatchingQueue.poll();
						if(!Teat.girlMatchingQueue.isEmpty()){
							//girlSessionId = MatchUtil.girlMatchingQueue.poll();
							System.out.println("=========3333=======");
						}
					}
				}
			}

			private void send(Session session, String message) {
				session.getAsyncRemote().sendText(message);
			}
			
		}).start();;
		
		new Thread(new Runnable(){

			@Override
			public void run() {
				while(true){
					System.out.println("===========22222===========");
					synchronized (girlMatchingQueue) {
						
						String boySessionId = "";
						while(girlMatchingQueue.isEmpty());
						String girlSessionId = girlMatchingQueue.poll();
						if(!Teat.boyMatchingQueue.isEmpty()){
							boySessionId = Teat.boyMatchingQueue.poll();
							System.out.println("===========44444===========");
						}
					}
				}
			}

			private void send(Session session, String message) {
				session.getAsyncRemote().sendText(message);
			}
			
		}).start();
	}
}
