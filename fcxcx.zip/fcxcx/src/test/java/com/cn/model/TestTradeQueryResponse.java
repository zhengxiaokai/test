package com.cn.model;

public class TestTradeQueryResponse {
}
