package com.cn.websocket;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.cn.common.Config;
import com.cn.entity.ChatRecord;
import com.cn.exception.ExceptionHandler;
import com.cn.kafka.producer.KafkaProducer;
import com.cn.redis.RedisService;
import com.cn.service.StoreChatRecordService;
import com.cn.util.ExceptionUtil;
@ServerEndpoint(value = "/websocket/{sendUser}")
@Component
public class MyWebSocket {
	//Lock lock = new ReentrantLock(); 
	//private static Map<String,Condition> condictionMap = new ConcurrentHashMap<String, Condition>();
	private static Logger logger = LoggerFactory.getLogger(MyWebSocket.class);
	private static ExecutorService fixedThreadPool = Executors.newFixedThreadPool(10);
	/**
     * 存放所有在线的客户端
     */
    public static Map<String, MyWebSocket> clients = new ConcurrentHashMap<String, MyWebSocket>();
    //private static Map<String, String> matchedMap = new ConcurrentHashMap<String, String>();
    //private static Queue<String> boyMatchingList = new ConcurrentLinkedQueue<String>();
    //private static Queue<String> girlMatchingList = new ConcurrentLinkedQueue<String>();
    //private static Map<String, Object> memberUserInfo = new ConcurrentHashMap<String, Object>();
    
    //private static List<String> boyMatchingList = new ArrayList<String>();//男生正在匹配的集合
    //private static List<String> girlMatchingList = new ArrayList<String>();//女生正在匹配的集合
    private Session session;
    
    private boolean isComplete = false;
    
    private String openId;
    
    private String webSocketKey;
    
    private static ApplicationContext applicationContext;
    
    public static void setApplicationContext(ApplicationContext context) {
        applicationContext = context;
    }
    
    private static RedisService redisService;
    
    public void setIsCompleteTrue(){
    	this.isComplete = true;
    }
    
    public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}
	
	/*public static void main(String[] args) {
		System.out.println(System.currentTimeMillis());
		System.out.println(UUID.randomUUID());
	}*/

	@OnOpen
    public void onOpen(Session session) {
    	logger.info("new client conneting: "+session.getId());
    	logger.info("new client uri: "+session.getRequestURI());
    	String uri = session.getRequestURI().toString();
    	this.openId = uri.substring(uri.lastIndexOf("/")+1);
    	this.session = session;
    	if(redisService == null){
    		synchronized (MyWebSocket.class) {
    			redisService = applicationContext.getBean(RedisService.class);
			}
    		
    	}
    	webSocketKey = System.currentTimeMillis()+"&"+openId+"&"+Config.serverName;
    	redisService.hput("serverLocation", webSocketKey, Config.serverName);
    	
    	/*String connectnum = redisService.hget("connectNum", "num")+"";
    	if(StringUtils.isEmpty(connectnum)){
    		redisService.hput("connectNum", "num", "0");
    	}*/
        //将新用户存入在线的组
    	System.out.println("webSocketKey:"+webSocketKey);
        clients.put(webSocketKey, this);
        //condictionMap.put(webSocketKey, lock.newCondition());
    }

    /**
     * 客户端关闭
     * @param session session
     */
    @OnClose
    public void onClose(Session session) {
    	logger.info("client close, id:"+session.getId());
    	//String sessionId = session.getId()+"&"+Config.serverName;
    	RedisService redisService = applicationContext.getBean(RedisService.class);
    	Object otherWebSocketKey = redisService.hget("matchedMap",webSocketKey);
    	Map<String,Object> result = new HashMap<>();
    	result.put("status", "5");
    	result.put("msg", "系统提示：对方已断开,可以等待对方连接...");
    	sendMsg(this.session,otherWebSocketKey,result);
        //将掉线的用户移除在线的组里
        clients.remove(session.getId());
        /*redisService.hRemove("matchedMap", webSocketKey);
        redisService.hRemove("serverLocation", webSocketKey);
        redisService.hRemove("matchedMap", otherWebSocketKey.toString());
        redisService.hRemove("serverLocation", otherWebSocketKey.toString());*/
    }

    /**
     * 发生错误
     * @param throwable e
     */
    @OnError
    public void onError(Throwable throwable,Session session) {
    	logger.info("onError sessionId:"+session.getId());
    	clients.remove(session.getId());
        throwable.printStackTrace();
    }

    /**
     * 收到客户端发来消息
     * @param message  消息对象
     */
    @OnMessage
    public void onMessage(Session session,String message) {
    	Map<String,Object> result = null;
    	try {
    		result = new HashMap<String,Object>();
			Map<String,Object> msg = JSON.parseObject(message);
			//String sessionId = session.getId()+"&"+Config.serverName;
			//logger.info("sessionId: "+sessionId);
			logger.info("client message: "+message);
			String type = msg.get("type")+"";
			RedisService redisService = applicationContext.getBean(RedisService.class);
   
			if("beginMatch".equals(type)){
				//Object otherWebSocketKey = redisService.hget("matchedMap",webSocketKey);
				Object otherWebSocketKey = msg.get("contactMemberSocketKey");
				
				Map userInfo = (Map)msg.get("userInfo");
				userInfo.put("name", msg.get("name")+"");
				//解密敏感信息
				/*String encryptedData = msg.get("encryptedData").toString();
				String iv = msg.get("iv").toString();
				String code = msg.get("code").toString();
				String anonymousCode = msg.get("anonymousCode").toString();
				String sessionKey = TtUtils.code2Session(code, anonymousCode).get("session_key").toString();
				String encryptedRes = TtUtils.decrypt(encryptedData, sessionKey, iv);
				Map res = JSON.parseObject(encryptedRes, Map.class);
				String openId = res.get("openId").toString();
				res.put("name", msg.get("name"));*/
				redisService.hput("memberUserInfo", openId, JSON.toJSONString(userInfo));
				//memberUserInfo.put(sessionId, userInfo);
		        
				final String sex = msg.get("sex")+"";
				if(sex != null && !"".equals(sex.trim())){
					if("1".equals(sex)){
						redisService.listLeftPush("boyMatchingList", webSocketKey);
						//redisService.sPut("boyMatchingList", sessionId);
					}else if("2".equals(sex)){
						redisService.listLeftPush("girlMatchingList", webSocketKey);
						//redisService.sPut("girlMatchingList", sessionId);
					}else{
						result.put("status", "9999");
			    		result.put("msg", "性别不正确");
			    		this.send(this.session,JSON.toJSONString(result));
						return;
					}
					fixedThreadPool.execute(
							new Runnable(){
								@Override
								public void run() {
									beginMatch(sex,session,userInfo);
								}
								
							}
					);  
					result.put("status", Config.matching);//代表匹配中
		    		result.put("msg", "匹配中");
		    		this.send(session,JSON.toJSONString(result));
		    		return;
				}  
			}else if("chat".equals(type)){
				
				String sendMessage = msg.get("sendMessage")+"";
				
				if(sendMessage == null || "".equals(sendMessage.trim())){
					result.put("status", "9999");//代表已经匹配过了
					result.put("msg", "发送内容不能为空");//代表已经匹配过了
					this.send(session,JSON.toJSONString(result));
				}
				String name = msg.get("name")+"";
				
				//String otherWebSocketKey = redisService.hget("matchedMap", webSocketKey)+"";
				String otherWebSocketKey = msg.get("contactMemberSocketKey").toString();
				result.put("contactMemberSocketKey", webSocketKey);
				System.out.println(otherWebSocketKey+"==>"+webSocketKey);
				result.put("status", Config.chatting);//代表正在匹配中
				result.put("msg", sendMessage);//发送的消息
				result.put("name", name);//名称
				String serverName = otherWebSocketKey.toString().split("&")[2];
				logger.info("this serverName:"+Config.serverName);
				logger.info("other serverName:"+serverName);
				logger.info("send msg:"+JSON.toJSONString(result));
				this.kafkaSend(otherWebSocketKey.toString(),JSON.toJSONString(result),serverName);
				
				ChatRecord chatRecord = new ChatRecord();
				chatRecord.setContent(sendMessage);
				chatRecord.setOpenId(openId);
				chatRecord.setOrderNo("");
				chatRecord.setUsername(name);
				//存储聊天记录
				StoreChatRecordService storeChatRecordService = applicationContext.getBean(StoreChatRecordService.class);
				storeChatRecordService.insert(chatRecord);
			}else if("holdConnect".equals(type)){
				//保持心跳
				logger.info("sessionId holdConnect:"+session.getId());
			}/*else if("closeSession".equals(type)){
				session.close();
			}*/
		} catch (Exception e) {
			e.printStackTrace();
			result.clear();
			result.put("status", Config.matching);//代表正在匹配中
			result.put("msg", "发送失败，请重新发送");
			this.send(session,JSON.toJSONString(result));
			ExceptionHandler eh = applicationContext.getBean(ExceptionHandler.class);
			ExceptionUtil.insertExceptionLog(e,eh);
		}
    }
    
    private void beginMatch(final String sex,Session session,Map<String,Object> userInfo){
    	
    	//String sessionId = session.getId()+"&"+Config.serverName;
    	//另一个sessionId
    	Object otherWebSocketKey = redisService.hget("matchedMap", webSocketKey);
    	if(otherWebSocketKey != null && StringUtils.isNotBlank(otherWebSocketKey.toString())){
    	
    	}else if("1".equals(sex)){
    		String girlWebSocketKey = "";
    		
    		while(StringUtils.isBlank(girlWebSocketKey = redisService.listRightPop("girlMatchingList"))){
    			if(isComplete){
    				return;
    			}
    		}
    		/*String matchKey = "";
    		
    		while(true){
	    		if(){
	    			String boyWebSocketKey = redisService.listRightPop("boyMatchingList");
	    			if(!StringUtils.isBlank(boyWebSocketKey)){
	    				matchKey = boyWebSocketKey;
	    				break;
	    			}
	    		}else{
	    			matchKey = girlWebSocketKey;
	    			break;
	    		}
    		}*/
    		setMatch(webSocketKey,girlWebSocketKey);
    		otherWebSocketKey = girlWebSocketKey;
    		System.out.println("girlWebSocketKey:"+girlWebSocketKey);
    	}else if("2".equals(sex)){
    		String boyWebSocketKey = "";
    		while(StringUtils.isBlank(boyWebSocketKey = redisService.listRightPop("boyMatchingList"))){
    			if(isComplete){
    				return;
    			}
    		}
    		
			setMatch(webSocketKey,boyWebSocketKey);
			otherWebSocketKey = boyWebSocketKey;
			System.out.println("boyWebSocketKey:"+boyWebSocketKey);
    	}
    	Map<String,Object> result = new HashMap<>();
    	result.put("status", "0");
    	result.put("mySocketKey", webSocketKey);
    	result.put("msg", "匹配成功");
    	Object contactMember = redisService.hget("memberUserInfo",otherWebSocketKey.toString().split("&")[1]);
		
		result.put("contactMemberInfo", contactMember);
		result.put("contactMemberSocketKey", otherWebSocketKey);
    	String message = JSON.toJSONString(result);
    	
    	this.send(this.session, message);
    	result.put("contactMemberInfo", JSON.toJSONString(userInfo));
    	result.put("contactMemberSocketKey", webSocketKey);
    	result.put("mySocketKey", otherWebSocketKey);
    	message = JSON.toJSONString(result);
    	sendMsg(this.session,otherWebSocketKey,result);
    	//kafkaSend(otherWebSocketKey.toString(),message,otherWebSocketKey.toString().split("&")[2]);
    }
    
    private void setMatch(String webSocketKey1,String webSocketKey2){
    	RedisService redisService = applicationContext.getBean(RedisService.class);
    	redisService.hput("matchedMap", webSocketKey1, webSocketKey2);
    	redisService.hput("matchedMap", webSocketKey2,webSocketKey1);
    }
    
    private void sendMsg(Session session,Object otherWebsocketKey,Map<String,Object> result){
    	String serverName = redisService.hget("serverLocation", otherWebsocketKey.toString())+"";
		String owk = otherWebsocketKey.toString();
    	if(Config.serverName.equals(owk.split("&")[2])){
			//String sendWebsocketKey = owk;
			this.send(clients.get(otherWebsocketKey).session,JSON.toJSONString(result));
		}else{
			this.kafkaSend(otherWebsocketKey.toString(),JSON.toJSONString(result),serverName);
		}
    }
    
    private void kafkaSend(String otherWebsocketKey,String message,String serverName){
    	Map<String,Object> msg = JSON.parseObject(message);
    	msg.put("myWebsocketKey", otherWebsocketKey);
    	KafkaProducer kafkaProducer = applicationContext.getBean(KafkaProducer.class);
    	kafkaProducer.sendMessage(serverName, JSON.toJSONString(msg));
    }
    
    private void send(Session session,String message){
    	session.getAsyncRemote().sendText(message);
    }
    
    /**
     * 群发消息
     * @param message 消息内容
     */
    /*private void sendAll(String message) {
        for (Map.Entry<String, Session> sessionEntry : clients.entrySet()) {
            sessionEntry.getValue().getAsyncRemote().sendText(message);
        }
    }*/
}
