package com.cn.websocket;

import java.util.Date;

import org.springframework.jdbc.core.JdbcTemplate;

import com.cn.entity.ChatRecord;

public class StoreChatRecord implements Runnable{
	
	private ChatRecord chatRecord;
	private JdbcTemplate jdbcTemplate;
	public StoreChatRecord(ChatRecord chatRecord,JdbcTemplate jdbcTemplate){
		this.chatRecord = chatRecord;
		this.jdbcTemplate = jdbcTemplate;
	}
	public void run() {
		String sql = "insert into chat_record(content,openId,username,createDate,status) values(?,?,?,?,?)";
        jdbcTemplate.update(sql, new Object[] {chatRecord.getContent(),chatRecord.getOpenId()
        		,chatRecord.getUsername(),new Date(),"1000"});
	}

}
