package com.cn.common;

public class Config {
	public final static String serverName = "server001";
	public final static int firstMatchStatus = 0;//第一次匹配
	public final static int alreadyMatchStatus = 1;//已经匹配过了再次进入
	public final static int noMatchStatus = -1;//还未匹配
	public final static int chatting = 2;//正在交流中
	public final static int matching = 3;//正在匹配中
	public final static int holdConnet = 4;//正在匹配中
	public final static String appId = "ttd8eaae5747c08233";
	public final static String appSecret = "1801b0ed9badaae446f14ed74381f0d8e3bf801c";
}
