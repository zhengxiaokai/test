package com.cn.common.domain;

import java.io.Serializable;

public class PageReqDomain   implements Serializable
{
	   protected int pageSize;
	   protected int pageIndex;

	   public int getPageSize()
	   {
	     return this.pageSize;
	   }

	   public void setPageSize(int pageSize) {
	     this.pageSize = pageSize;
	   }

	   public int getPageIndex() {
	     return this.pageIndex;
	   }

	   public void setPageIndex(int pageIndex) {
	     this.pageIndex = pageIndex;
	   }
}
