package com.cn.common.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.annotation.Resource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;

import com.cn.common.domain.PageReqDomain;
import com.cn.common.domain.PageResultDomain;

public class BaseDao {
	@Resource
	protected JdbcTemplate jdbcTemplate;
	public PageResultDomain paginSelect(final Class clazz,String sql, PageReqDomain pageReqDomain){
		final int pageSize = pageReqDomain.getPageSize();
		final int pageNumber = pageReqDomain.getPageIndex();
		int start = (pageNumber-1)*pageSize+1;
		StringBuffer sb = new StringBuffer();
		sb.append("select count(0) from (").append(sql).append(") t;");
		sb.append(sql).append(" limit ").append(start).append(",").append(pageSize);
		PageResultDomain pageResultDomain = jdbcTemplate.execute(sb.toString(), new PreparedStatementCallback<PageResultDomain>(){

			public PageResultDomain doInPreparedStatement(PreparedStatement ps)
					throws SQLException, DataAccessException {
				PageResultDomain pageResultDomain = new PageResultDomain();
				pageResultDomain.setPageSize(pageSize);
				pageResultDomain.setPageIndex(pageNumber);
				boolean resultsAvailable = ps.execute();
				int i = 0;
				Object[] rows = null;
		        //遍历结果集
				int j = 0;
		        while (resultsAvailable) {
		            ResultSet resultSet = ps.getResultSet();
		            while (resultSet.next()) {
		               if(i==0){
		            	   int total = resultSet.getInt(1);
		            	   pageResultDomain.setTotal(total);
		            	   rows = new Object[pageSize];
		               }else{
		            	   Object o = com.cn.util.RowMapper.getEntity(resultSet,clazz);
		            	   rows[j++] = o;
		               }
		            }
		            i++;
		            resultsAvailable = ps.getMoreResults();
		        }
		        pageResultDomain.setRows(rows);
		        return pageResultDomain;
			}
       	
       });
       return pageResultDomain;
	}
}
