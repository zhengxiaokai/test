package com.cn.common.domain;

public class PageResultDomain {
	  /**
	   * 记录的总数
	   */
	  protected int total;
	  /**
	   * 每页有多少数据
	   */
	  protected int pageSize;
	  /**
	   * 第几条数据
	   */
	  protected int pageIndex;
	  /**
	   * 有多少页，即页数
	   */
	  protected int pageCount;
	  /**
	   * 需要放置的数据
	   */
	  protected Object[] rows;

	  public int getTotal()
	  {
	    return this.total;
	  }

	  public void setTotal(int total) {
	    this.total = total;
	  }

	  public Object[] getRows() {
	    return this.rows;
	  }

	  public void setRows(Object[] rows) {
	    this.rows = rows;
	  }

	  public int getPageIndex() {
	    return this.pageIndex;
	  }

	  public void setPageIndex(int pageIndex) {
	    this.pageIndex = (pageIndex > getPageCount() ? getPageCount() : pageIndex);
	    if (this.pageIndex <= 0)
	      this.pageIndex = 1; 
	  }

	  public int getPageSize() { return this.pageSize; }

	  public void setPageSize(int pageSize) {
	    this.pageSize = pageSize;
	    setPageCount();
	  }
	  protected void setPageCount() {
	    if ((this.total == 0) || (this.pageSize == 0))
	      this.pageCount = 0;
	    else
	      this.pageCount = (this.total % this.pageSize == 0 ? this.total / this.pageSize : this.total / this.pageSize + 1);
	  }

	  public int getPageCount() {
	    return this.pageCount;
	  }
}
