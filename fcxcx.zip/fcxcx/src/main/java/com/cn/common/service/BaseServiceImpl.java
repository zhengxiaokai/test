package com.cn.common.service;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com.cn.dao")
public class BaseServiceImpl {

}
