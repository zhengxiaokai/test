package com.cn.schedule;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.websocket.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.cn.common.Config;
import com.cn.redis.RedisService;
import com.cn.websocket.MyWebSocket;

@Configuration      //1.主要用于标记配置类，兼备Component的效果。
@EnableScheduling   // 2.开启定时任务
public class CheckSessionScheduleTask {
	@Autowired
	RedisService redisService;
	 //3.添加定时任务
    //@Scheduled(cron = "0/10 * * * * ?")
    //或直接指定时间间隔，例如：10秒
    @Scheduled(fixedRate=10000)
    private void configureTasks() {
    	System.out.println("===========定时任务执行=============");
    	Map<String, MyWebSocket> clients = MyWebSocket.clients;
    	
    	/*Map memberUserInfo = redisService.hgetAll("memberUserInfo");
    	for(Object key : memberUserInfo.keySet()){
    		if(key != null){
    			String serverName = key.toString().split("&")[1];
    			if(Config.serverName.equals(serverName)){
    				if(!clients.containsKey(key)){
    					
    				}
    			}
    		}
    	}*/
    	
    	
    	for(String websocketKey:redisService.listGetAll("girlMatchingList")){
    		if(clients.containsKey(websocketKey)){
    			if(!clients.get(websocketKey).getSession().isOpen()){
    				clients.remove(websocketKey);
    			}else{
    				redisService.listRemove("girlMatchingList", websocketKey);
    			}
    		}
    	}
    	for(String websocketKey:redisService.listGetAll("boyMatchingList")){
    		if(clients.containsKey(websocketKey)){
    			if(!clients.get(websocketKey).getSession().isOpen()){
    				clients.remove(websocketKey);
    			}else{
    				redisService.listRemove("boyMatchingList", websocketKey);
    			}
    		}
    	}
    	Map matchedMap = redisService.hgetAll("matchedMap");
    	for(Object websocketKey:matchedMap.entrySet()){
    		if(clients.containsKey(websocketKey)){
    			if(!clients.get(websocketKey).getSession().isOpen()){
    				clients.remove(websocketKey);
    			}else{
    				redisService.hRemove("matchedMap", websocketKey.toString());
    			}
    		}
    	}
        for(String key:clients.keySet()){
        	Session session = clients.get(key).getSession();
        	if(!session.isOpen()){
        		clients.remove(key);
        		//String sessionId = session.getId() + "&" + Config.serverName;
        		redisService.hRemove("matchedMap", key);
                redisService.hRemove("serverLocation", key);
                redisService.hRemove("memberUserInfo",key);
                Object otherWebSocketKey = redisService.hget("matchedMap",key);
                if(otherWebSocketKey != null){
	                redisService.hRemove("matchedMap", otherWebSocketKey.toString());
	                redisService.hRemove("serverLocation", otherWebSocketKey.toString());
	                redisService.hRemove("memberUserInfo",otherWebSocketKey.toString());
                }
        	}
        }
    }
    
}
