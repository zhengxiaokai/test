package com.cn.dao;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.cn.common.dao.BaseDao;
import com.cn.common.domain.PageReqDomain;
import com.cn.common.domain.PageResultDomain;
import com.cn.entity.User;

@Repository
public class UserDao extends BaseDao{
	
	public User getUserByUserName(User user){
        StringBuffer sql = new StringBuffer("select * from user where 1 = 1 and user_name = ? ");
        RowMapper<User> rowMapper = new BeanPropertyRowMapper<User>(User.class);
        List list =  jdbcTemplate.query(sql.toString(), new Object[] {user.getUserName()}, rowMapper);
        return (User)((list != null && list.size() > 0)? list.get(0):null);
	}
	
	public PageResultDomain findAll(final Class clazz,PageReqDomain pageReqDomain){
		String sql = "select * from user";
		pageReqDomain.setPageIndex(1);
		pageReqDomain.setPageSize(20);
		return super.paginSelect(clazz, sql, pageReqDomain);
		/*StringBuffer sql = new StringBuffer("select count(0) from user;select * from user;");
		 PageResultDomain pageResultDomain = jdbcTemplate.execute(sql.toString(), new CallableStatementCallback<PageResultDomain>(){

		public PageResultDomain doInCallableStatement(CallableStatement cs)
					throws SQLException, DataAccessException {
				PageResultDomain pageResultDomain = new PageResultDomain();
				boolean resultsAvailable = cs.execute();
				int i = 0;
				Object[] rows = null;
		        //遍历结果集
				int j = 0;
		        while (resultsAvailable) {
		            ResultSet resultSet = cs.getResultSet();
		            while (resultSet.next()) {
		               if(i==0){
		            	   int total = resultSet.getInt(1);
		            	   pageResultDomain.setTotal(total);
		            	   rows = new Object[total];
		               }else{
		            	   Object o = com.cn.util.RowMapper.getEntity(resultSet,clazz);
		            	   rows[j++] = o;
		               }
		            }
		            i++;
		            resultsAvailable = cs.getMoreResults();
		        }
		        pageResultDomain.setRows(rows);
		        return pageResultDomain;
			}
        	
        });
        return pageResultDomain;*/
	}

	public void addUser(User user) {
		String sql = "insert into user(user_name,password) values(?,?)";
        jdbcTemplate.update(sql, new Object[] {user.getUserName(),user.getPassword()});
	}
	
	public User login(User user){
		String sql = "select * from user where 1 = 1 and user_name = ? and password = ? ";
		RowMapper<User> rowMapper = new BeanPropertyRowMapper<User>(User.class);
        List list =  jdbcTemplate.query(sql.toString(), new Object[] {user.getUserName(),user.getPassword()}, rowMapper);
        return (User)((list != null && list.size() > 0)? list.get(0):null);
	}
}
