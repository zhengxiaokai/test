package com.cn.entity;

public class Customer implements java.io.Serializable{
	private Long id;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
}
