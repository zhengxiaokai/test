package com.cn.entity;

import org.springframework.beans.factory.annotation.Configurable;

@Configurable
public class RiskAssessor {

}
