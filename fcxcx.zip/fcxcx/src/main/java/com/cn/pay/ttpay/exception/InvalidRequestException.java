package com.cn.pay.ttpay.exception;

public class InvalidRequestException extends Exception {

    private static final long serialVersionUID = 1L;

    public InvalidRequestException(String message) {
        super(message, null);
    }

    public InvalidRequestException(String message, Throwable e) {
        super(message, e);
    }
}

