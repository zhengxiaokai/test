package com.cn.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cn.entity.Role;

@RestController
@Configuration
@RequestMapping(path="/roleManageController")
public class RoleManageController {
	private final Logger logger = LoggerFactory.getLogger("RoleManageController"); 
	@RequestMapping(path="/queryRole")
	public Object queryRole() {
		//System.out.println("======id====>"+id);
		return getTableJson();
	}
	
	private Map<String,Object> getTableJson(){
		Role role1 = new Role(); 
		role1.setId(1L);
		role1.setName("张三");
		role1.setMoney(123);
		role1.setAddress("广东省东莞市长安镇");
		role1.setState("成功");
		role1.setDate("2020-03-07");
		role1.setThumb("https://lin-xin.gitee.io/images/post/wms.png");
		
		Role role2 = new Role(); 
		role2.setId(1L);
		role2.setName("张三");
		role2.setMoney(123);
		role2.setAddress("广东省东莞市长安镇");
		role2.setState("成功");
		role2.setDate("2020-03-07");
		role1.setThumb("https://lin-xin.gitee.io/images/post/wms.png");
		
		Role role3 = new Role(); 
		role3.setId(1L);
		role3.setName("张三");
		role3.setMoney(123);
		role3.setAddress("广东省东莞市长安镇");
		role3.setState("成功");
		role3.setDate("2020-03-07");
		role3.setThumb("https://lin-xin.gitee.io/images/post/wms.png");
		
		List<Role> list = new ArrayList<Role>();
		list.add(role1);
		list.add(role2);
		list.add(role3);
		
		Map<String,Object> rs = new HashMap<String,Object>();
		rs.put("list", list);
		return rs;
	}
}
