package com.cn.controller;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.cn.entity.User;
import com.cn.kafka.producer.KafkaProducer;
import com.cn.redis.RedisService;
import com.cn.util.CookiesUtil;
import com.cn.util.TtUtils;
import com.cn.websocket.MyWebSocket;

@RestController
@RequestMapping(value="/TtController")
public class TtController {
	@Autowired
	private RedisService redisService;
	@Autowired
	private KafkaProducer kafkaProducer;
	@RequestMapping(value = "/getSessionKey",method = RequestMethod.POST)
    public @ResponseBody Map getSessionKey(HttpServletRequest request,HttpServletResponse response,@RequestBody Map<String,Object> params){
		String code = params.get("code")+"";
		String anonymousCode = params.get("anonymousCode")+"";
		Map result = TtUtils.code2Session(code,anonymousCode);
        return result;
    }
	
	@RequestMapping(value = "/getOpenId",method = RequestMethod.POST)
	public @ResponseBody Map getOpenId(HttpServletRequest request,HttpServletResponse response,@RequestBody Map<String,Object> params){
		try {
			String encryptedData = params.get("encryptedData").toString();
			String iv = params.get("iv").toString();
			String code = params.get("code").toString();
			String anonymousCode = params.get("anonymousCode").toString();
			String sessionKey = TtUtils.code2Session(code, anonymousCode).get("session_key").toString();
			String encryptedRes = TtUtils.decrypt(encryptedData, sessionKey, iv);
			Map res = JSON.parseObject(encryptedRes, Map.class);
			Object openId = res.get("openId");
			res.clear();
			res.put("openId", openId);
			System.out.println("openId:"+JSON.toJSONString(res));
			return res;
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	@RequestMapping(value = "/closeSession",method = RequestMethod.POST)
	public @ResponseBody Map closeSession(HttpServletRequest request,HttpServletResponse response,@RequestBody Map<String,Object> params){
		Map<String,String> res = new HashMap<>();
		try {
			String webSocketKey = params.get("mySocketKey").toString();
			String otherWebSocketKey = params.get("contactMemberSocketKey").toString();
			redisService.hRemove("matchedMap", webSocketKey);
	        redisService.hRemove("serverLocation", webSocketKey);
	        redisService.hRemove("matchedMap", otherWebSocketKey);
	        redisService.hRemove("serverLocation", otherWebSocketKey);
	        MyWebSocket myWebSocket = MyWebSocket.clients.get(webSocketKey);
	        
	        if(myWebSocket != null){
	        	Session session = myWebSocket.getSession();
	        	if(session != null && session.isOpen()){
	        		session.close();
	        	}
	        }
	        Map<String,Object> result = new HashMap<>();
	    	result.put("status", "6");
	    	result.put("msg", "系统提示：对方已退出，请重新匹配...");
	    	String serverName = otherWebSocketKey.toString().split("&")[2];
	        kafkaSend(otherWebSocketKey,JSON.toJSONString(result),serverName);
	        res.put("status", "0");
		} catch (Exception e) {
			res.put("status", "-1");
			e.printStackTrace();
		} 
		return res;
	}
	
	private void kafkaSend(String otherWebsocketKey,String message,String serverName){
    	Map<String,Object> msg = JSON.parseObject(message);
    	msg.put("myWebsocketKey", otherWebsocketKey);
    	kafkaProducer.sendMessage(serverName, JSON.toJSONString(msg));
    }
}
