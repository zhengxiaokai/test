package com.cn.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class MatchContorller {
	
	static{
		System.out.println();
	}
	
	@RequestMapping(value="/sendUser",method = RequestMethod.POST)
    public void startMatch(@RequestBody Map<String, String> map) {
		log.info("==========开始匹配===============");
    }
}
