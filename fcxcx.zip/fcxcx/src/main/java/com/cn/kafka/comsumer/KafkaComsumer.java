package com.cn.kafka.comsumer;

import java.util.HashMap;
import java.util.Map;

import javax.websocket.Session;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.cn.common.Config;
import com.cn.exception.ExceptionHandler;
import com.cn.kafka.producer.KafkaProducer;
import com.cn.redis.RedisService;
import com.cn.util.ExceptionUtil;
import com.cn.websocket.MyWebSocket;

@Component
public class KafkaComsumer {
	private static Logger logger = LoggerFactory.getLogger(KafkaComsumer.class);
	@Autowired
	RedisService redisService;
	//@Autowired
	KafkaProducer kafkaProducer;
	@Autowired
	ExceptionHandler exceptionHandler;
	private final KafkaTemplate kafkaTemplate;

	//@Autowired
	public KafkaComsumer(KafkaTemplate kafkaTemplate) {
		this.kafkaTemplate = kafkaTemplate;
	}
	
	//@KafkaListener(topics = Config.serverName)
	public void processMessage(ConsumerRecord<String,String> record) {
		logger.info("record.value():"+record.value());
		try {
			Map<String, MyWebSocket> clients = MyWebSocket.clients;
			Map<String,Object> result = new HashMap<>();
			Map<String,Object> messageInfo = JSON.parseObject(record.value(),Map.class);
			Object myWebsocketKey = messageInfo.get("myWebsocketKey").toString();
			try {
				logger.info("myWebsocketKey:"+myWebsocketKey);
				MyWebSocket ms = clients.get(myWebsocketKey.toString());
				ms.setIsCompleteTrue();
				this.send(ms.getSession(),JSON.toJSONString(messageInfo));
			} catch (Exception e) {
				result.clear();
				result.put("status", Config.matching);//代表正在匹配中
				result.put("msg", "发送失败，请重新发送");
				//this.send(clients.get(myWebsocketKey.toString().split("&")[0]),JSON.toJSONString(result));
				ExceptionUtil.insertExceptionLog(e,exceptionHandler);
				
			}
		} catch (Exception e) {
			ExceptionUtil.insertExceptionLog(e,exceptionHandler);
		}
	}
	
	private void send(Session session,String message){
    	session.getAsyncRemote().sendText(message);
    }
	
}
