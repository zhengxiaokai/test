package com.cn.util;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.cn.common.Config;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class TtUtils {
	/**
	 * 获取access_token
	 * @return
	 */
	public static Map<String,Object> getAccessToken(){
		Map param = new HashMap();
    	param.put("appid", Config.appId);
    	param.put("secret", Config.appSecret);
    	param.put("grant_type", "client_credential");
    	String baseUrl = "https://developer.toutiao.com/api/apps/token";
		String res = HttpUtil.doGet(baseUrl, param);
		Map tokenInfo = JSON.parseObject(res, Map.class);
		return tokenInfo;
	}
	/**
	 * 获取session_key和openId
	 * 返回结果：{"anonymous_openid":"hjDBwUfA6ny.VAVc","error":0,"openid":"WLi1hMeeGRfjKHk8","session_key":"FGOVNOB5/NPeM65kAN71YA=="}
	 * @param code
	 * @param anonymous_code
	 * @return
	 */
	public static Map<String,Object> code2Session(String code,String anonymousCode){
		Map param = new HashMap();
    	param.put("appid", Config.appId);
    	param.put("secret", Config.appSecret);
    	param.put("code", code);
    	param.put("anonymous_code", anonymousCode);
    	String baseUrl = "https://developer.toutiao.com/api/apps/jscode2session";
		String res = HttpUtil.doGet(baseUrl, param);
		System.out.println(res);
		Map sessionInfo = JSON.parseObject(res, Map.class);
		return sessionInfo;
	}
	
	public static String decrypt(String encryptedData, String sessionKey, String iv) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        Base64.Decoder decoder = Base64.getDecoder();
        byte[] sessionKeyBytes = decoder.decode(sessionKey);
        byte[] ivBytes = decoder.decode(iv);
        byte[] encryptedBytes = decoder.decode(encryptedData);

        // JDK does not support PKCS7Padding, use PKCS5Padding instead
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        SecretKeySpec skeySpec = new SecretKeySpec(sessionKeyBytes, "AES");
        IvParameterSpec ivSpec = new IvParameterSpec(ivBytes);
        cipher.init(Cipher.DECRYPT_MODE, skeySpec, ivSpec);
        byte[] ret = cipher.doFinal(encryptedBytes);
        return new String(ret);
    }
	
	public static void main(String[] args) {
	}
}
