package com.cn.util;

import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.cn.exception.ExceptionHandler;

public class ExceptionUtil {
	private static ExecutorService fixedThreadPool = Executors.newFixedThreadPool(2);
	public static String getExceptionString(Exception e){
		StringBuffer errorString = new StringBuffer();
		for(StackTraceElement se : e.getStackTrace()){
			errorString.append(se.toString());
		}
		return errorString.toString();
	}
	
	public static void insertExceptionLog(Exception e,ExceptionHandler eh){
		eh.setContent(ExceptionUtil.getExceptionString(e));
		eh.setType("9");
		eh.setCreateDate(new Date());
		eh.setStatus("9999");
		fixedThreadPool.execute(eh);
	}
}
