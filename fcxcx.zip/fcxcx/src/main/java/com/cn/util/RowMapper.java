package com.cn.util;

import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class RowMapper{
	public static Object getEntity(ResultSet resultSet,Class clazz) throws SQLException{
		Object o = null;
		try {
			o = clazz.newInstance();
		    ResultSetMetaData meta = resultSet.getMetaData();
		    int colcount = meta.getColumnCount();
		    for (int j = 1; j <= colcount; j++) {
		        String name = meta.getColumnLabel(j);
		        String methodName = RefletionUtils.getSetMethodName(name);
		        Object value = resultSet.getObject(j);
		        String fieldName = RefletionUtils.getFieldName(name.toLowerCase());
		        Class type = clazz.getDeclaredField(fieldName).getType();
				Method method = clazz.getDeclaredMethod(methodName,type);
				if(value != null){
					if(value instanceof Integer && type == Long.class){
						method.invoke(o, Long.valueOf(value.toString()));
					}else{
						method.invoke(o, value);
					}
				}
				
		    }
		} catch (Exception e) {
			e.printStackTrace();
		}
		return o;
	}
}
