package com.cn.util;

import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

public class RESTfulClient {
	 public static String SERVER_URL = "";
    public static String REQUEST_PATH = "";
    public static String REQUEST_URL = SERVER_URL + REQUEST_PATH;
    public static String GET_CONTENT_TYPE = "application/json";
    public static String GET_ACCEPT = "application/json";
    public static String GET_CHARSET = "UTF-8";
    
    public static String PUT_CONTENT_TYPE = "text/plain";
    public static String PUT_ACCEPT = "application/json";
    public static String PUT_CHARSET = "UTF-8";
    
    public static String POST_CONTENT_TYPE = "application/json";
    public static String POST_ACCEPT = "application/json";
    public static String POST_CHARSET = "UTF-8";
    
	public static String executeGet(String path)
            throws HttpHostConnectException, IOException {
        String fullPath = SERVER_URL + path;
        HttpGet httpQuery = new HttpGet(fullPath);
        httpQuery.addHeader("Accept", "text/plain;charset=UTF-8");// );
        httpQuery.addHeader("Accept", "application/json");
        return doRequest(httpQuery);

    }
    
    public static String executePost(String path, String body)
            throws IOException {
        HttpPost httpQuery = new HttpPost(SERVER_URL + path);
        System.out.println("request Path : " + SERVER_URL + path);
        httpQuery.addHeader("Content-Type", POST_CONTENT_TYPE);
        httpQuery.addHeader("Accept", POST_ACCEPT);
        httpQuery.addHeader("charset", POST_CHARSET);
        if (null != body) {
            StringEntity se = new StringEntity(body);
            httpQuery.setEntity(se);
        }
        return doRequest(httpQuery);
    }
    
    private static String doRequest(HttpRequestBase httpQuery)
            throws ParseException, IOException, HttpHostConnectException {
        String content = null;
        final HttpParams httpParams = new BasicHttpParams();
        HttpConnectionParams.setConnectionTimeout(httpParams, 10000);
        DefaultHttpClient httpClient = new DefaultHttpClient(httpParams);
        HttpResponse httpResponse = httpClient.execute(httpQuery);
        HttpEntity entity = null;
        entity = httpResponse.getEntity();

        if (null != entity) {
            content = EntityUtils.toString(entity, HTTP.UTF_8);
        }

        return content;
    }
    
    public static void main(String[] args) {
		
	}
}
