/*package com.cn.util;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

import javax.websocket.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.cn.kafka.producer.KafkaProducer;
import com.cn.redis.RedisService;
import com.cn.websocket.MyWebSocket;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class MatchUtil implements ApplicationRunner{
	@Autowired
	RedisService redisService;
	@Autowired
	KafkaProducer kafkaProducer;
	
	private void setMatch(String sessonId1,String sessionId2){
    	redisService.hput("matchedMap", sessonId1, sessionId2);
    	redisService.hput("matchedMap", sessionId2,sessonId1);
    }
	
	@Override
	public void run(ApplicationArguments args) throws Exception {
		Map<String,Object> result = new HashMap<>();
		result.put("status", 0);
		result.put("msg", "匹配成功"); 
		new Thread(new Runnable(){

			@Override
			public void run() {
				while(true){
					System.out.println("=========11111111111=======");
					String girlSessionId = "";
					while(redisService.sGet("boyMatchingList") == null || redisService.sGet("boyMatchingList").size() <= 0);
					String boySessionId = redisService.sGet("boyMatchingList").iterator().next();
					while(redisService.sGet("girlMatchingList") == null || redisService.sGet("girlMatchingList").size() <= 0);
					girlSessionId = redisService.sGet("girlMatchingList").iterator().next();
					System.out.println("============girlSessionId=========="+girlSessionId);
					System.out.println("============girlSessionId.split(&)[1]=========="+girlSessionId.split("&")[1]);
					this.kafkaSend(girlSessionId,JSON.toJSONString(result),girlSessionId.split("&")[1]);
					this.send(MyWebSocket.clients.get(boySessionId), JSON.toJSONString(result));
					
					
					setMatch(boySessionId,girlSessionId);
					redisService.sRemove("girlMatchingList", girlSessionId);
					redisService.sRemove("boyMatchingList", boySessionId);
				}
			}

			private void send(Session session, String message) {
				session.getAsyncRemote().sendText(message);
			}
			
			private void kafkaSend(String otherSessionId,String message,String serverName){
		    	Map<String,Object> msg = JSON.parseObject(message);
		    	msg.put("mySessionId", otherSessionId);
		    	kafkaProducer.sendMessage(serverName, JSON.toJSONString(msg));
		    }
			
		}).start();;
		
	}
}
*/