package com.cn.util;

import java.lang.reflect.Method;

import org.apache.commons.lang.StringUtils;

import com.cn.entity.User;
import com.cn.exception.AlertException;

public class RefletionUtils{
	public static Object invokeSetMethod(String prpertyName,Object value,Class clazz){
		System.out.println(clazz.getName());
		try {
			Object o = clazz.newInstance();
			String methodName = getSetMethodName(prpertyName);
			Method method = clazz.getDeclaredMethod(methodName,value.getClass());
			return method.invoke(o, value);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	public static void main(String[] args) throws AlertException, NoSuchFieldException, SecurityException {
		//sLong o = null;
		//System.out.println(o);
		String name = "user_name";
		System.out.println(getSetMethodName(name));
		RefletionUtils.invokeSetMethod("user_name", "1111", User.class);
		//System.out.println(getSetMethodName("sys"));
	}
	
	public static String getFieldName(String colName){
		StringBuffer fieldName = new StringBuffer();
		if(colName.contains("_")){
			String[] words = colName.split("_");
			for(int i=0;i<words.length;i++){
				if(i != 0){
					fieldName.append(words[i].substring(0, 1).toUpperCase()).append(words[i].substring(1));
				}else{
					fieldName.append(words[i]);
				}
			}
			return fieldName.toString();
		}
		return colName;
		
	}
	
	public static String getSetMethodName(String methodName) throws AlertException{
		if(StringUtils.isNotBlank(methodName)){
			StringBuffer setMethodName = new StringBuffer("set");
			if(methodName.contains("_")){
				String[] words = methodName.split("_");
				for(String word:words){
					setMethodName.append(word.substring(0, 1).toUpperCase()).append(word.substring(1));
				}
			}else{
				setMethodName.append(methodName.substring(0, 1).toUpperCase()).append(methodName.substring(1));
			}
			return setMethodName.toString();
		}
		throw new AlertException("参数methodName不能为空");
	}
}
