package com.cn.service;

public interface AccountService {

}
