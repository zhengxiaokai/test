package com.cn.service;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.cn.entity.ChatRecord;
import com.cn.websocket.StoreChatRecord;

@Service
public class StoreChatRecordService {
	@Resource
	protected JdbcTemplate jdbcTemplate;
	private static ExecutorService fixedThreadPool = Executors.newFixedThreadPool(1);
	
	public void insert(ChatRecord chatRecord){
		fixedThreadPool.execute(new StoreChatRecord(chatRecord,jdbcTemplate));  
	}
}
