package com.cn.redis;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class RedisService {
	@Autowired
	private StringRedisTemplate template;
	
	public void setTemplate(StringRedisTemplate template) {
		this.template = template;
	}
	
	public void put(String key,String value){
		template.opsForValue().set(key, value);
	}
	
	public String get(String key){
		return template.opsForValue().get(key);
	}
	
	public void remove(String key){
		template.delete(key);
	}
	
	public void hput(String mapName,String key,String value){
		if(template.opsForHash().hasKey(mapName, key)){
			template.opsForHash().delete(mapName, key);
		}
		template.opsForHash().put(mapName, key, value);
	}
	
	public Object hget(String mapName,String key){
		return template.opsForHash().get(mapName, key);
	}
	
	public Map hgetAll(String mapName){
		return template.opsForHash().entries(mapName);
	}
	
	public void hRemove(String mapName,String key){
		template.opsForHash().delete(mapName, key);
	}
	
	public void sPut(String key,String value){
		String[] values = {value};
		template.opsForSet().add(key, values);
	}
	
	public Set<String> sGet(String key){
		return template.opsForSet().members(key);
	}
	
	public void sPop(String key){
		template.opsForSet().pop(key);
	}
	
	public void sRemove(String key,String value){
		String[] values = {value};
		template.opsForSet().remove(key, values);
	}
	
	public void listLeftPush(String listName,String key){
		template.opsForList().leftPush(listName, key);
	}
	
	public String listRightPop(String listName){
		return template.opsForList().rightPop(listName);
	}
	
	public List<String> listGetAll(String listName){
		return template.opsForList().range(listName,0,-1);
	}
	
	public void listRemove(String listName,String value){
		template.opsForList().remove(listName, 0, value);
	}
}
